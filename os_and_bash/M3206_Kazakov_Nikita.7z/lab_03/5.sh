mkfifo channel
./5_helper_1.sh &
./5_helper_2.sh
rm channel
