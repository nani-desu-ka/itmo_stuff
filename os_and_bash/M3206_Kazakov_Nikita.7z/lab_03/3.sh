echo "*/5 * * * 6 1.sh" | crontab
