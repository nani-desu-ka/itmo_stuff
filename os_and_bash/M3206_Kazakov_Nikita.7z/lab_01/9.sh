sudo cat /var/log/*.log | wc -l
