./6_helper_1.sh  & pid=$!
./6_helper_2.sh $pid
