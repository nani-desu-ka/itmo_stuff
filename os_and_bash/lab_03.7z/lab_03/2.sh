at now + 2 minute -f ./1.sh &
tail -n 0 -f ~/report &
