while true; do
    result=1*1
done
