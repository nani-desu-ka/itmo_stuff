#include "../include/Manager.hpp"

Manager *Manager::manager = nullptr;
